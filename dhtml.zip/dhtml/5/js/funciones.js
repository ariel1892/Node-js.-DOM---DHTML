function cambiarTexto() {
    let tit = document.getElementById('titulo')
    tit.childNodes[0].nodeValue = 'Ahora vemos el nuevo título'
}

