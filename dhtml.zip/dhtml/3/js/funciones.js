function cambiarColor() {
    let tit = document.getElementById('titulo')
    tit.style.color = '#ff0000'
}

function cambiarTamanoFuente() {
    let tit = document.getElementById('titulo')
    tit.style.fontSize = '60px'
}